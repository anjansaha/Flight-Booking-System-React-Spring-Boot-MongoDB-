package com.kush.FlightUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightUserApplication.class, args);
	}

}
