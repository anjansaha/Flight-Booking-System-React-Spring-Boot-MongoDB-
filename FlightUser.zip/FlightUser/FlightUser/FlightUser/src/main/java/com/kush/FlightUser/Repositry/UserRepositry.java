package com.kush.FlightUser.Repositry;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.kush.FlightUser.model.User;

public interface UserRepositry extends MongoRepository<User, String>{

}
