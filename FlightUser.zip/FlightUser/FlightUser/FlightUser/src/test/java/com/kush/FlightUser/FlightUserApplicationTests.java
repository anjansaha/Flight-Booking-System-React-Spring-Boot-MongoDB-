package com.kush.FlightUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
